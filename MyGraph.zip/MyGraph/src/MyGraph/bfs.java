package MyGraph;

import java.util.Scanner;
public class bfs{
public static void main(String args[]){
	Scanner sc = new Scanner(System.in);
		
		System.out.print("how many points the graph will have : ");
 		int points = sc.nextInt();
 		if(points<1)
 		{
 	    	for(;points<1;)
 	    	{
 	 	  System.out.print("how many points the graph will have : ");
 	 		points = sc.nextInt();
 	 		}
 	    	}
 		System.out.print("Input a starting point, between 1 and the number of  points : ");
		int starting_point = sc.nextInt();
		if(starting_point<1 || starting_point>points)
		{
	 		for(;starting_point<1 || starting_point>points;)
	 		{
	 	 	System.out.print("Input a starting point, between 1 and the number of  points : ");
			starting_point = sc.nextInt();
			}
	 		}
		int queue[] = new int[100];int s[][] = new int[100][100];int b[] = new int[100];
	    int copy_3=0, previous_point=0, copy=starting_point, i=0, j=0, m=0, l=0, checking=1;
		for(;i<points;)
		{
			System.out.print("how many will the connected points to point "+(i+1)+" be , between 1 and the number of the points: ");
			queue[i] = sc.nextInt();
			if(queue[i]<1 || queue[i]>points)
			{
		 		while(queue[i]<1 || queue[i]>points)
		 		{
		 	 	System.out.print("how many will the connected points to point "+(i+1)+" be , between 1 and the number of the points: ");
				queue[i] = sc.nextInt();
		 	}
		 		}
			queue[i]=queue[i];
			for(;j<queue[i];)
			{
				if(j==0)System.out.print("Input a point, which is connected to point number "+(i+1)+", between 1 and the number of the points :  ");
				else System.out.print("Input a point, which is connected to point number "+(i+1)+", between "+copy_3+" and the number of the points :  ");
				s[i+1][j]= sc.nextInt();
				if(j==0)
				{
					    if(s[i+1][j]<1 ||s[i+1][j]>points)
					    {
			 		    for(;s[i+1][j]<1 || s[i+1][j]>points;)
			 		    {
			 			System.out.print("Input a point, which is connected to point number "+(i+1)+", between 1 and the number of the points :  ");
						s[i+1][j] = sc.nextInt();
						}
			 		    }
					    }
				   else{
				        if(s[i+1][j]<=copy_3 || s[i+1][j]>points)
				        {
			 	     	for(;s[i+1][j]<=copy_3 || s[i+1][j]>points;)
			 	     	{
			 			System.out.print("Input a point, which is connected to point number "+(i+1)+", between "+copy_3+" and the number of the points :  ");
						s[i+1][j] = sc.nextInt();}}}
			copy_3=s[i+1][j];				
			j++;
			}
			j=0;
			i++;
			}
		i=0;	
		System.out.print("The way from point  number " + starting_point + " to everything else is : ");
		for(;i<points;)
		{
	    if(i==0)System.out.print(starting_point);
		for(;j<=queue[i];)
		{
				for(;checking ==1;)
				{
					if(s[starting_point][j]== b[m])
					{checking=0;break;}
					if(b[m]==0)break;
					if(s[starting_point][j]==previous_point)
					{checking=0;break;}
					if(s[starting_point][j]==copy)
					{checking=0;break;}
				m++;
				}
				m=0;
				if(checking==1)
				{
				b[l]=s[starting_point][j];				
				System.out.print(" -> "+s[starting_point][j]);
				l++;
				}
				j++;
	         	checking=1;
	         	}
	    j=0;
		previous_point=starting_point;
		i++;
		starting_point=b[i-1];
		}
}
}